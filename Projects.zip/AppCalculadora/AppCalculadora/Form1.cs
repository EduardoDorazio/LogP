﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsomar_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtnum1.Text);
            float varNum2 = float.Parse(txtnum2.Text);
            float resultado;

            //soma
            resultado = varNum1 + varNum2;
            MessageBox.Show("soma " + resultado);
        }

        private void btnsubtrair_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtnum1.Text);
            float varNum2 = float.Parse(txtnum2.Text);
            float resultado;

            //subtração
            resultado=varNum1 - varNum2;
            MessageBox.Show("subtração: " + resultado);
        }

        private void btnmultiplicar_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtnum1.Text);
            float varNum2 = float.Parse(txtnum2.Text);
            float resultado;

            //multiplicação 
            resultado = (varNum1 * varNum2);
            MessageBox.Show("multiplicação: " + resultado);
        }

        private void btndividir_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtnum1.Text);
            float varNum2 = float.Parse(txtnum2.Text);
            float resultado;

            //divisão
            resultado=(varNum1 / varNum2);
            MessageBox.Show("divisão: " + resultado);
        }
    }
}
