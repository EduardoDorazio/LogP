﻿namespace FrmDados
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.btnEntrar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(592, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(478, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Capturando Dados da Tela ";
            // 
            // txtInteiro
            // 
            this.txtInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInteiro.Location = new System.Drawing.Point(783, 212);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(229, 38);
            this.txtInteiro.TabIndex = 1;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtTexto
            // 
            this.txtTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTexto.Location = new System.Drawing.Point(783, 288);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(229, 38);
            this.txtTexto.TabIndex = 2;
            // 
            // txtDecimal
            // 
            this.txtDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimal.Location = new System.Drawing.Point(783, 359);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(229, 38);
            this.txtDecimal.TabIndex = 3;
            // 
            // txtBoleano
            // 
            this.txtBoleano.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoleano.Location = new System.Drawing.Point(783, 433);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(229, 38);
            this.txtBoleano.TabIndex = 4;
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.BackColor = System.Drawing.Color.Transparent;
            this.lblInteiro.ForeColor = System.Drawing.SystemColors.Control;
            this.lblInteiro.Location = new System.Drawing.Point(780, 196);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(36, 13);
            this.lblInteiro.TabIndex = 5;
            this.lblInteiro.Text = "Inteiro";
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.BackColor = System.Drawing.Color.Transparent;
            this.lblTexto.ForeColor = System.Drawing.SystemColors.Control;
            this.lblTexto.Location = new System.Drawing.Point(780, 272);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(34, 13);
            this.lblTexto.TabIndex = 6;
            this.lblTexto.Text = "Texto";
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.BackColor = System.Drawing.Color.Transparent;
            this.lblDecimal.ForeColor = System.Drawing.SystemColors.Control;
            this.lblDecimal.Location = new System.Drawing.Point(780, 343);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(48, 13);
            this.lblDecimal.TabIndex = 7;
            this.lblDecimal.Text = "Decimal ";
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.BackColor = System.Drawing.Color.Transparent;
            this.lblBoleano.ForeColor = System.Drawing.SystemColors.Control;
            this.lblBoleano.Location = new System.Drawing.Point(780, 417);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(46, 13);
            this.lblBoleano.TabIndex = 8;
            this.lblBoleano.Text = "Boleano";
            // 
            // btnEntrar
            // 
            this.btnEntrar.BackColor = System.Drawing.Color.Green;
            this.btnEntrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntrar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEntrar.Location = new System.Drawing.Point(617, 568);
            this.btnEntrar.Name = "btnEntrar";
            this.btnEntrar.Size = new System.Drawing.Size(161, 77);
            this.btnEntrar.TabIndex = 9;
            this.btnEntrar.Text = "Entrar";
            this.btnEntrar.UseVisualStyleBackColor = false;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Red;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSair.Location = new System.Drawing.Point(851, 568);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(161, 77);
            this.btnSair.TabIndex = 10;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FrmDados.Properties.Resources.neymar__above;
            this.ClientSize = new System.Drawing.Size(1082, 667);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnEntrar);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Button btnEntrar;
        private System.Windows.Forms.Button btnSair;
    }
}

